# OT-SecureGate · Evaluación Sumativa Unidad 2

Aplicación Android en **Kotlin con Jetpack Compose y Material 3** que continúa la propuesta OT-SecureGate de la Unidad 1. Dos teléfonos representan los nodos de una zona industrial restringida: un **nodo de acceso** (RFID y barrera simulados) y un **nodo de monitoreo** (PIR, reed switch y alarma simulados). Intercambian eventos en ambos sentidos mediante **Bluetooth Classic RFCOMM seguro**, y cada teléfono guarda su bitácora en **SQLite privado**.

> \\\*\\\*Alcance académico:\\\*\\\* la Unidad 1 propuso dos Arduino Uno, lectores y actuadores. Esta versión de la Unidad 2 \\\*\\\*simula\\\*\\\* los sensores y actuadores en Android; no controla placas Arduino ni equipamiento OT real. No debe usarse como control de seguridad industrial ni como protección de acceso físico.

## Requisitos

* Android Studio con JDK 17, Android SDK 35 y soporte para Kotlin/Gradle y Jetpack Compose.
* Dos teléfonos Android 8.0 (API 26) o superior, ambos con **Bluetooth Classic**.
* Android Gradle Plugin 8.9.2, Kotlin 2.0.21, plugin Compose Compiler 2.0.21, Compose BOM 2025.04.01, Material 3 y Gradle Wrapper 8.11.1 (se descargan durante sincronización).
* No se requieren Firebase, MySQL, APIs externas ni Internet para el funcionamiento.

## Cómo abrir, compilar e instalar

1. Descomprime el proyecto y abre **la carpeta `OT-SecureGate-U2`** con `File > Open` en Android Studio.
2. Espera la sincronización de Gradle. Si se solicita, instala **Android SDK Platform 35** desde SDK Manager. Android Studio puede descargar automáticamente el Gradle Wrapper.
3. Conecta un teléfono con depuración USB y elige `Run > Run app`. Repite en el segundo dispositivo. Para una APK de pruebas, elige `Build > Build APK(s)`; aparece en `app/build/outputs/apk/debug/app-debug.apk`.
4. **En el primer inicio de cada teléfono**, crea un usuario administrador local con contraseña de al menos 10 caracteres. Cada equipo posee su propia base SQLite.
5. En **Ajustes > Bluetooth** de ambos teléfonos, enciende Bluetooth y **emparéjalos entre sí**. Confirma cualquier solicitud del sistema.
6. Abre OT-SecureGate en el teléfono A, inicia sesión, selecciona `Nodo 1 · Control de acceso` y toca `Esperar conexión`.
7. En el teléfono B, inicia sesión, selecciona `Nodo 2 · Monitoreo OT`, toca `Conectar a emparejado` y elige el teléfono A. Si Android pide permiso de **Dispositivos cercanos**, concédelo y repite el botón.
8. Confirma `Conectado mediante Bluetooth seguro` en **ambos**. Intercambia eventos: credencial autorizada/denegada desde A, movimiento/puerta/solicitud de cierre desde B.
9. Comprueba la **bitácora SQLite** de ambos teléfonos: un evento generado en A debe figurar como `LOCAL` en A y `REMOTO` en B (y viceversa).

Nota: algunos fabricantes restringen conexiones RFCOMM, la visibilidad o el emparejamiento entre teléfonos. Mantén ambas apps **abiertas en primer plano** durante la demostración, porque esta versión no implementa servicio Bluetooth en segundo plano.

## Interfaz Jetpack Compose

* `MainActivity` es una `ComponentActivity` cuyo contenido se presenta con `setContent { ... }`.
* Las pantallas de login y panel, los diálogos de usuarios y dispositivos, las tarjetas, botones y registros se implementan con **composables Material 3** (`OutlinedTextField`, `ElevatedCard`, `FilterChip`, `AlertDialog`, etc.).
* Se utilizan `mutableStateOf` y recomposición para reflejar el estado de sesión, barrera, Bluetooth y eventos; **no hay layouts de pantalla en XML ni `LinearLayout`/`EditText` programáticos**.
* Android Studio permite previsualizar y modificar la interfaz Compose; el backend sigue siendo Kotlin nativo con Bluetooth y SQLite.

## Pantallas

1. **Crear administrador / Login:** usuario y contraseña local; tras cinco intentos incorrectos, pausa de 30 s mientras la app permanece abierta.
2. **Panel principal:** selector de rol, estado de Bluetooth, escuchar/conectar/desconectar, botones de simulación y bitácora.
3. **Dispositivos emparejados:** selector del sistema integrado en un diálogo; la app no explora el entorno ni requiere permiso de ubicación.
4. **Administración:** el administrador puede crear operadores locales; cerrar sesión termina el enlace y deja la barrera simulada cerrada.

## Protocolo y seguridad

* Se usa `listenUsingRfcommWithServiceRecord` / `createRfcommSocketToServiceRecord` con un UUID exclusivo del proyecto, que emplea el enlace RFCOMM seguro **autenticado y cifrado por Bluetooth**.
* Cada mensaje lleva longitud de 4 bytes seguida de JSON UTF-8. Se rechazan tramas de más de **2048 bytes**, versión no admitida, tipos no definidos, identificadores mal formados y marcas de tiempo con desfase mayor a 24 h.
* Las claves de acceso local se guardan como verificadores **PBKDF2-HMAC-SHA256**, 150.000 iteraciones, sal aleatoria de 16 bytes. **No se almacenan contraseñas en claro**.
* SQLite reside en almacenamiento privado de la aplicación; `allowBackup=false`. No se pide permiso de Internet.
* Cada evento tiene identificador UUID único; SQLite ignora duplicados. Solo se aceptan los eventos definidos en `GateEvent.TYPES`.
* Las órdenes remotas están limitadas a **cierre seguro**; no existe una orden remota para abrir una barrera física. Ante salida, reinicio o cambio de rol, la barrera virtual queda cerrada.
* El protocolo no verifica una identidad de usuario remoto independiente del emparejamiento Bluetooth ni realiza atestación de dispositivos. Se requiere una política de emparejamiento de confianza para un uso más serio.

### Eventos de demostración

|Evento|Originador|Acción representada|
|-|-|-|
|`ACCESS\\\_OK`|Acceso|Credencial ficticia OT-1001 aceptada; apertura simulada 5 s|
|`ACCESS\\\_DENIED`|Acceso|Rechazo; barrera cerrada|
|`BARRIER\\\_CLOSED`|Acceso|Cierre local o por temporizador|
|`MOTION`|Monitoreo|PIR detecta movimiento|
|`DOOR\\\_OPEN`|Monitoreo|Reed switch detecta puerta abierta|
|`REMOTE\\\_LOCK`|Monitoreo|Solicitud segura de cierre al nodo de acceso|
|`ALARM\\\_RESET`|Monitoreo|Restablecimiento de alarma simulado|

## 

## Correspondencia con la guía

* **2.1.1:** Android Studio, Kotlin, Jetpack Compose Material 3, SQLite privado, autenticación local, validación de datos.
* **2.1.2:** aplicación Android con Bluetooth Classic RFCOMM e interfaz para sensores/actuadores simulados.
* **2.1.3:** controles de seguridad inspirados en los lineamientos generales de ISO/IEC 27400:2022; **no implica certificación ISO ni cumplimiento integral auditado**.
* **2.1.4:** dos instalaciones Android con funciones de escucha/conexión e intercambio de eventos bidireccional; requiere demostración física.

## Fuentes técnicas

* [Android Developers — Permisos Bluetooth](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions)
* [Android Developers — Conectar dispositivos Bluetooth](https://developer.android.com/develop/connectivity/bluetooth/connect-bluetooth-devices)
* [Android Developers — SQLite](https://developer.android.com/training/data-storage/sqlite)
* [Android Developers — Compose Compiler y dependencias](https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler)
* [ISO — ISO/IEC 27400:2022](https://www.iso.org/standard/44373.html)

**Autor de la entrega Grupal:** Esteban Rojas, Vicente Galassi, Franco Aranguiz · Ingeniería en Ciberseguridad · TI3042 · Octubre 2026.

