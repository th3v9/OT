package cl.otsg.securegate

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Private, offline SQLite store. Passwords are never saved: PBKDF2 salt + verifier only. */
class GateDatabase(context: Context) : SQLiteOpenHelper(context, "securegate.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users (username TEXT PRIMARY KEY, role TEXT NOT NULL, salt BLOB NOT NULL, verifier BLOB NOT NULL)")
        db.execSQL("CREATE TABLE events (id TEXT PRIMARY KEY, time INTEGER NOT NULL, type TEXT NOT NULL, source TEXT NOT NULL, detail TEXT NOT NULL, origin TEXT NOT NULL)")
        db.execSQL("CREATE INDEX events_time_idx ON events(time DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // No schema migrations are required for the first academic version.
    }

    fun hasUsers(): Boolean = readableDatabase.rawQuery("SELECT 1 FROM users LIMIT 1", null)
        .use { it.moveToFirst() }

    fun createUser(username: String, password: CharArray, role: String): Boolean {
        if (!username.matches(Regex("[a-zA-Z0-9_.-]{3,32}")) || password.size < 10 || password.size > 128) return false
        if (role !in setOf("ADMIN", "OPERADOR")) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val verifier = derive(password, salt)
        return try {
            val values = ContentValues().apply {
                put("username", username)
                put("role", role)
                put("salt", salt)
                put("verifier", verifier)
            }
            writableDatabase.insertOrThrow("users", null, values) > 0
        } catch (_: SQLiteConstraintException) {
            false
        } finally {
            verifier.fill(0)
            salt.fill(0)
        }
    }

    fun verifyUser(username: String, password: CharArray): String? {
        val cursor = readableDatabase.query(
            "users", arrayOf("role", "salt", "verifier"), "username=?",
            arrayOf(username), null, null, null
        )
        cursor.use {
            if (!it.moveToFirst()) return null
            val role = it.getString(0)
            val salt = it.getBlob(1)
            val expected = it.getBlob(2)
            val actual = derive(password, salt)
            val correct = MessageDigest.isEqual(actual, expected)
            actual.fill(0)
            return if (correct) role else null
        }
    }

    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, 150_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun addEvent(event: GateEvent, origin: String): Boolean {
        if (origin !in setOf("LOCAL", "REMOTO")) return false
        val values = ContentValues().apply {
            put("id", event.id)
            put("time", event.time)
            put("type", event.type)
            put("source", event.source)
            put("detail", event.detail)
            put("origin", origin)
        }
        return writableDatabase.insertWithOnConflict(
            "events", null, values, SQLiteDatabase.CONFLICT_IGNORE
        ) != -1L
    }

    fun recentEvents(limit: Int = 15): List<Pair<GateEvent, String>> {
        val items = mutableListOf<Pair<GateEvent, String>>()
        readableDatabase.query(
            "events", arrayOf("id", "time", "type", "source", "detail", "origin"),
            null, null, null, null, "time DESC", limit.coerceIn(1, 50).toString()
        ).use { c ->
            while (c.moveToNext()) {
                items += GateEvent(c.getString(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4)) to c.getString(5)
            }
        }
        return items
    }
}
