package cl.otsg.securegate

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Android-to-Android Bluetooth Classic RFCOMM over authenticated/encrypted paired link. */
class BluetoothLink(
    private val adapter: BluetoothAdapter?,
    private val onStatus: (String) -> Unit,
    private val onEvent: (GateEvent) -> Unit
) {
    companion object {
        // Project UUID: must match on both installations; not the standard SPP UUID.
        val SERVICE_UUID: UUID = UUID.fromString("2b1955e8-6b9b-4cdf-9c4c-955efac441ca")
    }

    private val generation = AtomicInteger(0)
    private val writer = Executors.newSingleThreadExecutor()
    private val sendLock = Any()

    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var listeningSocket: BluetoothServerSocket? = null

    fun isConnected(): Boolean = socket?.isConnected == true

    @SuppressLint("MissingPermission")
    fun listen() {
        stop()
        val token = generation.get()
        Thread {
            try {
                val bt = adapter ?: throw IOException("El equipo no admite Bluetooth")
                val server = bt.listenUsingRfcommWithServiceRecord("OTSecureGate-U2", SERVICE_UUID)
                listeningSocket = server
                if (generation.get() != token) { server.close(); return@Thread }
                onStatus("En espera de otro teléfono emparejado...")
                val accepted = server.accept()
                server.close()
                listeningSocket = null
                if (generation.get() != token) { accepted.close(); return@Thread }
                readLoop(accepted, token)
            } catch (e: Exception) {
                if (generation.get() == token) onStatus("Sin enlace: ${e.message ?: "error Bluetooth"}")
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        stop()
        val token = generation.get()
        Thread {
            try {
                onStatus("Conectando al teléfono emparejado...")
                val peer = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                socket = peer // Stop can close a connection still being established.
                peer.connect()
                if (generation.get() != token) { peer.close(); return@Thread }
                readLoop(peer, token)
            } catch (e: Exception) {
                if (generation.get() == token) onStatus("Conexión fallida: ${e.message ?: "revisar emparejamiento"}")
            }
        }.start()
    }

    private fun readLoop(peer: BluetoothSocket, token: Int) {
        socket = peer
        onStatus("Conectado mediante Bluetooth seguro")
        try {
            val input = DataInputStream(peer.inputStream)
            while (generation.get() == token) {
                val length = input.readInt()
                if (length !in 1..2048) throw IOException("Mensaje fuera del tamaño permitido")
                val payload = ByteArray(length)
                input.readFully(payload)
                GateEvent.parse(String(payload, Charsets.UTF_8))?.let(onEvent)
            }
        } catch (_: IOException) {
            // Closing the socket (locally or remotely) also terminates a blocking read.
        } finally {
            try { peer.close() } catch (_: IOException) { }
            if (generation.get() == token) {
                socket = null
                onStatus("Enlace cerrado; se requiere reconectar")
            }
        }
    }

    fun send(event: GateEvent) {
        val payload = event.toJson().toByteArray(Charsets.UTF_8)
        if (payload.size > 2048) return
        writer.execute {
            val current = socket ?: return@execute
            try {
                synchronized(sendLock) {
                    val output = DataOutputStream(current.outputStream)
                    output.writeInt(payload.size)
                    output.write(payload)
                    output.flush()
                }
            } catch (_: Exception) {
                onStatus("No se pudo transmitir el evento; revisar enlace")
            }
        }
    }

    fun stop() {
        generation.incrementAndGet()
        try { listeningSocket?.close() } catch (_: IOException) { }
        try { socket?.close() } catch (_: IOException) { }
        listeningSocket = null
        socket = null
        onStatus("Sin conexión")
    }

    fun shutdown() {
        stop()
        writer.shutdownNow()
    }
}
