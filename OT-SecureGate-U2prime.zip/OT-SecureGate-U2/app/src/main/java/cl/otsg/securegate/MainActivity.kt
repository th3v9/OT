package cl.otsg.securegate

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

/** Android UI is entirely Jetpack Compose + Material 3; no View/XML screen layouts. */
class MainActivity : ComponentActivity() {
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var database: GateDatabase
    private lateinit var link: BluetoothLink

    // Compose snapshot state replaces manually rebuilding a LinearLayout screen.
    private var account by mutableStateOf<String?>(null)
    private var accountRole by mutableStateOf<String?>(null)
    private var firstAccount by mutableStateOf(true)
    private var nodeRole by mutableStateOf("ACCESO")
    private var bluetoothStatus by mutableStateOf("Sin conexión")
    private var barrierOpen by mutableStateOf(false)
    private var eventItems by mutableStateOf<List<Pair<GateEvent, String>>>(emptyList())
    private var showDevicePicker by mutableStateOf(false)
    private var showAddOperator by mutableStateOf(false)
    private var pairedDevices by mutableStateOf<List<BluetoothDevice>>(emptyList())
    private var failedLogins = 0
    private var lockedUntil = 0L
    private val bluetoothPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        inform(if (granted) "Permiso concedido: repite la conexión" else "Se requiere permiso Dispositivos cercanos")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = GateDatabase(this)
        firstAccount = !database.hasUsers()
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        link = BluetoothLink(manager.adapter,
            onStatus = { status -> runOnUiThread { bluetoothStatus = status } },
            onEvent = { event -> runOnUiThread { receive(event) } }
        )
        refreshEvents()
        setContent {
            SecureGateTheme {
                Surface(color = CanvasColor, modifier = Modifier.fillMaxSize()) {
                    if (account == null) LoginScreen()
                    else DashboardScreen()
                }
            }
        }
    }

    override fun onDestroy() {
        link.shutdown()
        database.close()
        super.onDestroy()
    }

    private fun inform(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun authenticate(username: String, password: String) {
        val name = username.trim()
        val secret = password.toCharArray()
        try {
            if (firstAccount) {
                if (database.hasUsers()) {
                    firstAccount = false
                    inform("Ya existe una cuenta en este dispositivo")
                    return
                }
                if (!database.createUser(name, secret, "ADMIN")) {
                    inform("Usa 3 a 32 caracteres y una contraseña de 10 o más")
                    return
                }
                account = name
                accountRole = "ADMIN"
                firstAccount = false
                refreshEvents()
                return
            }

            if (System.currentTimeMillis() < lockedUntil) {
                inform("Demasiados intentos: espera 30 segundos")
                return
            }
            val verifiedRole = database.verifyUser(name, secret)
            if (verifiedRole == null) {
                failedLogins++
                if (failedLogins >= 5) {
                    lockedUntil = System.currentTimeMillis() + 30_000L
                    failedLogins = 0
                }
                inform("Credenciales incorrectas")
            } else {
                account = name
                accountRole = verifiedRole
                failedLogins = 0
                refreshEvents()
            }
        } finally {
            secret.fill('\u0000')
        }
    }

    private fun logout() {
        link.stop()
        account = null
        accountRole = null
        barrierOpen = false
        showDevicePicker = false
        showAddOperator = false
    }

    private fun selectRole(role: String) {
        if (role !in setOf("ACCESO", "MONITOREO")) return
        barrierOpen = false
        nodeRole = role
    }

    private fun refreshEvents() {
        eventItems = database.recentEvents()
    }

    private fun emit(type: String, detail: String) {
        val event = GateEvent.create(type, "${account ?: "sin_usuario"}:$nodeRole", detail)
        database.addEvent(event, "LOCAL")
        link.send(event)
        refreshEvents()
    }

    private fun receive(event: GateEvent) {
        if (account == null) return
        if (!database.addEvent(event, "REMOTO")) return
        if (nodeRole == "ACCESO" && event.type == "REMOTE_LOCK") barrierOpen = false
        refreshEvents()
    }

    private fun simulateAuthorizedAccess() {
        barrierOpen = true
        emit("ACCESS_OK", "Credencial de prueba autorizada; barrera simulada abierta")
        uiHandler.postDelayed({
            if (account != null && barrierOpen && nodeRole == "ACCESO") {
                barrierOpen = false
                emit("BARRIER_CLOSED", "Cierre automático después de 5 segundos")
            }
        }, 5000L)
    }

    private fun bluetoothReady(): Boolean {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null) {
            inform("Este dispositivo no admite Bluetooth Classic")
            return false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            bluetoothPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            return false
        }
        if (!adapter.isEnabled) {
            inform("Enciende Bluetooth desde Ajustes y vuelve a intentar")
            return false
        }
        return true
    }

    private fun startListening() {
        if (bluetoothReady()) link.listen()
    }

    @SuppressLint("MissingPermission")
    private fun choosePairedDevice() {
        if (!bluetoothReady()) return
        val adapter: BluetoothAdapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val devices = try { adapter.bondedDevices.toList().sortedBy { it.name ?: it.address } }
        catch (_: SecurityException) { inform("Permiso Bluetooth revocado"); return }
        if (devices.isEmpty()) {
            inform("Empareja los dos teléfonos desde Ajustes > Bluetooth")
            return
        }
        pairedDevices = devices
        showDevicePicker = true
    }

    @Composable
    private fun LoginScreen() {
        var username by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(35.dp))
            AppHeading("Seguridad de acceso y monitoreo OT")
            Spacer(Modifier.height(18.dp))
            SectionCard(if (firstAccount) "Crear administrador" else "Iniciar sesión") {
                Text(
                    if (firstAccount) "Primer uso: crea una cuenta local en cada teléfono."
                    else "Accede con las credenciales autorizadas para este equipo.",
                    color = MutedColor, fontSize = 14.sp
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Usuario") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Contraseña") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { authenticate(username, password); password = "" },
                    enabled = username.isNotBlank() && password.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (firstAccount) "Crear cuenta y continuar" else "Ingresar")
                }
            }
            Text(
                "Prototipo académico: los sensores RFID, PIR y la barrera se simulan.",
                modifier = Modifier.padding(top = 10.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MutedColor
            )
        }
    }

    @Composable
    private fun DashboardScreen() {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            AppHeading("Usuario: ${account ?: ""} · ${accountRole ?: ""}")

            SectionCard("Rol del teléfono") {
                Text("Selecciona roles distintos en los dos móviles.", color = MutedColor, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(selected = nodeRole == "ACCESO", onClick = { selectRole("ACCESO") }, label = { Text("Acceso · N1") })
                    FilterChip(selected = nodeRole == "MONITOREO", onClick = { selectRole("MONITOREO") }, label = { Text("Monitoreo · N2") })
                }
            }

            SectionCard("Interconexión Bluetooth") {
                Text(
                    bluetoothStatus,
                    color = if (link.isConnected()) AccentColor else MutedColor,
                    fontWeight = FontWeight.SemiBold
                )
                PrimaryAction("Esperar conexión (teléfono A)") { startListening() }
                SecondaryAction("Conectar a emparejado (teléfono B)") { choosePairedDevice() }
                SecondaryAction("Desconectar") { link.stop() }
                Text("Empareja primero ambos equipos desde los Ajustes Bluetooth de Android.", style = MaterialTheme.typography.bodySmall, color = MutedColor)
            }

            if (nodeRole == "ACCESO") {
                SectionCard("Nodo 1 · Control de acceso") {
                    Text(
                        "Barrera virtual: ${if (barrierOpen) "ABIERTA (prueba)" else "CERRADA (segura)"}",
                        fontWeight = FontWeight.SemiBold,
                        color = if (barrierOpen) AccentColor else NavyColor
                    )
                    PrimaryAction("Simular RFID autorizado OT-1001") { simulateAuthorizedAccess() }
                    SecondaryAction("Simular RFID desconocido") {
                        barrierOpen = false
                        emit("ACCESS_DENIED", "Credencial de prueba rechazada; barrera cerrada")
                    }
                    SecondaryAction("Cerrar barrera") {
                        barrierOpen = false
                        emit("BARRIER_CLOSED", "Cierre seguro solicitado localmente")
                    }
                }
            } else {
                SectionCard("Nodo 2 · Monitoreo OT") {
                    Text("PIR y reed switch se representan con eventos simulados.", color = MutedColor, fontSize = 14.sp)
                    PrimaryAction("Simular movimiento PIR") { emit("MOTION", "Movimiento detectado en zona OT") }
                    SecondaryAction("Simular puerta abierta") { emit("DOOR_OPEN", "Reed switch indica puerta abierta") }
                    SecondaryAction("Solicitar cierre remoto seguro") { emit("REMOTE_LOCK", "Solicitud de cierre desde nodo de monitoreo") }
                    SecondaryAction("Restablecer alarma") { emit("ALARM_RESET", "Operador restableció señal de alarma") }
                }
            }

            SectionCard("Bitácora local SQLite") {
                if (eventItems.isEmpty()) Text("Todavía no hay eventos.", color = MutedColor)
                eventItems.forEach { (event, origin) ->
                    EventRow(event, origin)
                    HorizontalDivider(color = Color(0xFFE4EAEE))
                }
            }

            SectionCard("Administración") {
                if (accountRole == "ADMIN") {
                    SecondaryAction("Crear usuario operador") { showAddOperator = true }
                }
                SecondaryAction("Cerrar sesión") { logout() }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (showDevicePicker) PairedDevicesDialog()
        if (showAddOperator) CreateOperatorDialog()
    }

    @SuppressLint("MissingPermission")
    @Composable
    private fun PairedDevicesDialog() {
        AlertDialog(
            onDismissRequest = { showDevicePicker = false },
            title = { Text("Dispositivos emparejados") },
            text = {
                Column(modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    pairedDevices.forEach { device ->
                        TextButton(onClick = {
                            showDevicePicker = false
                            link.connect(device)
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text("${device.name ?: "Dispositivo"} · ${device.address}")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDevicePicker = false }) { Text("Cancelar") } }
        )
    }

    @Composable
    private fun CreateOperatorDialog() {
        var username by remember { mutableStateOf("") }
        var password by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddOperator = false },
            title = { Text("Crear operador local") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, singleLine = true)
                    OutlinedTextField(password, { password = it }, label = { Text("Contraseña") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (accountRole != "ADMIN") return@TextButton
                    val secret = password.toCharArray()
                    val created = try { database.createUser(username.trim(), secret, "OPERADOR") }
                    finally { secret.fill('\u0000') }
                    password = ""
                    if (created) { showAddOperator = false; inform("Operador creado") }
                    else inform("Revisa el nombre y la contraseña de al menos 10 caracteres")
                }) { Text("Crear") }
            },
            dismissButton = { TextButton(onClick = { showAddOperator = false }) { Text("Cancelar") } }
        )
    }
}

private val NavyColor = Color(0xFF122741)
private val AccentColor = Color(0xFF007073)
private val CanvasColor = Color(0xFFF2F6F9)
private val MutedColor = Color(0xFF586977)

@Composable
private fun SecureGateTheme(content: @Composable () -> Unit) {
    val palette = lightColorScheme(
        primary = AccentColor,
        onPrimary = Color.White,
        background = CanvasColor,
        surface = Color.White,
        onSurface = NavyColor,
        outline = Color(0xFF97A7B4)
    )
    MaterialTheme(colorScheme = palette, content = content)
}

@Composable
private fun AppHeading(description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        Text("OT-SecureGate", color = NavyColor, fontWeight = FontWeight.Bold, fontSize = 29.sp)
        Text(description, color = MutedColor, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NavyColor)
            content()
        }
    }
}

@Composable
private fun PrimaryAction(caption: String, action: () -> Unit) {
    Button(onClick = action, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Text(caption)
    }
}

@Composable
private fun SecondaryAction(caption: String, action: () -> Unit) {
    OutlinedButton(onClick = action, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
        Text(caption)
    }
}

@Composable
private fun EventRow(event: GateEvent, origin: String) {
    val timestamp = remember(event.time) {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(Date(event.time))
    }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("$origin · ${event.type}", fontWeight = FontWeight.SemiBold, color = NavyColor)
        Text(event.detail, style = MaterialTheme.typography.bodySmall)
        Text("$timestamp · ${event.source}", style = MaterialTheme.typography.labelSmall, color = MutedColor)
    }
}
