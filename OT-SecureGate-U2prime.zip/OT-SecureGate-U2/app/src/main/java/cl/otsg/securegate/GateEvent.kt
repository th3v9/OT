package cl.otsg.securegate

import org.json.JSONObject
import java.util.UUID

/** Versioned, bounded, allowlisted demo protocol. Never carries user passwords or raw RFID data. */
data class GateEvent(
    val id: String,
    val time: Long,
    val type: String,
    val source: String,
    val detail: String
) {
    fun toJson(): String = JSONObject()
        .put("version", VERSION)
        .put("id", id)
        .put("time", time)
        .put("type", type)
        .put("source", source)
        .put("detail", detail)
        .toString()

    companion object {
        const val VERSION = 1
        val TYPES = setOf(
            "ACCESS_OK", "ACCESS_DENIED", "BARRIER_CLOSED",
            "MOTION", "DOOR_OPEN", "ALARM_RESET", "REMOTE_LOCK"
        )

        fun create(type: String, source: String, detail: String): GateEvent {
            require(type in TYPES)
            return GateEvent(
                UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                type,
                source.take(32),
                detail.take(120)
            )
        }

        fun parse(raw: String): GateEvent? {
            return try {
                if (raw.toByteArray(Charsets.UTF_8).size > 2048) return null
                val obj = JSONObject(raw)
                if (obj.getInt("version") != VERSION) return null
                val id = obj.getString("id")
                UUID.fromString(id)
                val time = obj.getLong("time")
                val type = obj.getString("type")
                val source = obj.getString("source")
                val detail = obj.getString("detail")
                val skew = kotlin.math.abs(System.currentTimeMillis() - time)
                if (skew > 24L * 60 * 60 * 1000) return null
                if (type !in TYPES || source.length !in 1..32 || detail.length > 120) return null
                if (source.any { it.isISOControl() } || detail.any { it.isISOControl() }) return null
                GateEvent(id, time, type, source, detail)
            } catch (_: Exception) {
                null
            }
        }
    }
}
